
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Magical Door Adventure</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
    <style>
        body {
            font-family: Arial, sans-serif;
            text-align: center;
            background-color: #f0f8ff; /* Light mode background */
            color: #000; /* Light mode text color */
            margin: 0;
            padding: 50px;
            transition: background-color 0.3s, color 0.3s; /* Smooth transition */
        }
        h1 {
            color: #9370db; /* Lighter purple for title in light mode */
        }
        .door-image {
            width: 200px; /* Set the width of the door images */
            height: 300px; /* Set a fixed height for uniformity */
            object-fit: cover; /* Maintain aspect ratio and cover the area */
            margin: 20px;
            cursor: pointer; /* Change cursor to pointer on hover */
            transition: transform 0.3s; /* Add transition for scaling effect */
        }
        img{
          border-radius: 10px;
        }
        footer {
            margin-top: 50px; /* Space above the footer */
            font-size: 14px; /* Font size for the footer */
            color: #555; /* Color for the footer text */
        }
        /* Dark mode styles */
        body.dark-mode {
            background-color: #121212; /* Dark mode background */
            color: #ffffff; /* Dark mode text color */
        }
        footer.dark-mode {
            color: #aaa; /* Dark mode footer text color */
        }
        .toggle-button {
            position: absolute; /* Position the button in the top right corner */
            top: 20px;
            right: 20px;
            background: none; /* No background */
            border: none; /* No border */
            cursor: pointer; /* Change cursor to pointer */
            font-size: 24px; /* Icon size */
            color: #9370db; /* Lighter purple for icon in light mode */
            transition: color 0.3s; /* Smooth transition for color */
        }


        body {
    perspective: 1000px; /* Add perspective to the body */
}

body {
    perspective: 1000px; /* Add perspective to the body */
}

.door-link {
    display: inline-block; /* Ensure the link behaves like a block for hover effect */
    transform-style: preserve-3d; /* Preserve 3D transformations */
    transition: transform 0.6s; /* Smooth transition for the rotation */
}

.door-link:hover {
    transform: rotateY(-120deg); /* Rotate the door to simulate opening */
}

.door-image {
    width: 200px; /* Set the width of the door images */
    height: 300px; /* Set a fixed height for uniformity */
    object-fit: cover; /* Maintain aspect ratio and cover the area */
    margin: 20px;
    border-radius: 10px;
    backface-visibility: hidden; /* Hide the back face when rotated */
} 

    </style>
</head>
<body>

    <h1>Welcome to the Magical Door Adventure!</h1>
    <button class="toggle-button" onclick="toggleDarkMode()">
        <i class="fas fa-moon"></i>
    </button>
    <p>Choose a door to begin your adventure:</p>

    <a class="door-link door-opening" href="red.php">
    <img class="door-image" src="red_door_image.jpg" alt="Red Door">
    </a>
<a class="door-link" href="blue.php">
    <img class="door-image" src="blue_door_image.jpg" alt="Blue Door">
</a>
<a class="door-link" href="green.php">
    <img class="door-image" src="green_door_image.jpg" alt="Green Door">
</a>


    <footer>
        © Ali Aiman 1K4
    </footer>

    <script>
        function toggleDarkMode() {
            document.body.classList.toggle('dark-mode');
            const footer = document.querySelector('footer');
            footer.classList.toggle('dark-mode');
            const icon = document.querySelector('.toggle-button i');
            // Change icon based on mode
            if (document.body.classList.contains('dark-mode')) {
              icon.classList.remove('fa-moon');
                icon.classList.add('fa-sun'); // Change to sun icon in dark mode
            } else {
                icon.classList.remove('fa-sun');
                icon.classList.add('fa-moon'); // Change back to moon icon in light mode
            }
        }
        function openDoor(event, doorLink) {
    event.preventDefault(); // Prevent the default link behavior
    const doorImage = event.currentTarget.querySelector('.door-image');
    doorImage.classList.add('door-opening'); // Add the animation class

    // Redirect after the animation ends
    doorImage.addEventListener('animationend', function() {
        window.location.href = doorLink; // Redirect to the door link
    }, { once: true }); // Use { once: true } to ensure the event listener is removed after it runs
}
    </script>

</body>
</html>