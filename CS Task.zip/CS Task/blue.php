<?php
echo '<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Blue Door Adventure</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
    <style>
        body {
            font-family: Arial, sans-serif;
            text-align: center;
            background-image: url("blue.jpg"); /* Set the background image */
            background-size: cover; /* Cover the entire background */
            background-position: center; /* Center the background image */
            margin: 0;
            padding: 0; /* Remove padding */
            height: 100vh; /* Full height of the viewport */
            display: flex; /* Use flexbox for centering */
            flex-direction: column; /* Stack elements vertically */
            justify-content: center; /* Center vertically */
            align-items: center; /* Center horizontally */
            position: relative; /* Position relative for the overlay */
            overflow: hidden; /* Prevent overflow */
        }
        .overlay {
            position: absolute; /* Position overlay absolutely */
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background-color: rgba(0, 0, 0, 0.5); /* Black with 50% transparency */
            z-index: 1; /* Ensure overlay is above the background */
        }
        h1 {
            position: relative; /* Position text above the overlay */
            z-index: 2; /* Ensure text is above the overlay */
            color: #1e90ff; /* Color for the title */
            font-size: 24px; /* Smaller font size for the title */
            text-shadow: 2px 2px 4px rgba(0, 0, 0, 0.7); /* Shadow for better readability */
            margin: 10px; /* Margin for spacing */
        }
        p {
            position: relative; /* Position text above the overlay */
            z-index: 2; /* Ensure text is above the overlay */
            color: #fff; /* Light text color for better contrast */
            font-size: 14px; /* Smaller font size for the story */
            line-height: 1.4; /* Line height for better readability */
            text-shadow: 1px 1px 3px rgba(0, 0, 0, 0.7); /* Shadow for better readability */
            width: 80%; /* Set a fixed width for better readability */
            margin: 10px auto; /* Center the paragraphs */
        }
        .back-button {
            position: absolute; /* Position the button absolutely */
            top: 20px; /* Distance from the top */
            left: 20px; /* Distance from the left */
            background-color: rgba(255, 255, 255, 0.8); /* Light background for the button */
            color: #000; /* Text color */
            border: none; /* No border */
            padding: 10px 15px; /* Padding for the button */
            border-radius: 5px; /* Rounded corners */
            cursor: pointer; /* Pointer cursor on hover */
            z-index: 2; /* Ensure button is above the overlay */
            font-size: 16px; /* Font size for the button */
        }
        .back-button:hover {
            background-color: rgba(255, 255, 255, 1); /* Change background on hover */
        }
    </style>
</head>
<body>

    <div class="overlay"></div> <!-- Overlay for transparency -->
    <button class="back-button" onclick="window.history.back();">Back</button> <!-- Back button -->
    <h1>Welcome to the Blue Door Adventure!</h1>
    <p>As you step through the blue door, you find yourself in a serene ocean world, where the waves gently lap against the shore and the sky is painted in shades of azure. The air is filled with the salty scent of the sea, and you can hear the distant calls of seagulls soaring above.</p>
    <p>You take a moment to soak in the beauty around you. The sun glistens on the water, creating a sparkling path that seems to invite you to explore further. As you walk along the beach, you notice colorful seashells scattered in the sand, each one telling a story of the ocean\'s adventures.</p>
    <p>As you wander along the shore, you come across a small boat bobbing gently in the water. Its vibrant blue color matches the door you just passed through, and it seems to beckon you closer. You can see fishing nets and a few shimmering fish caught in the nets, glistening in the sunlight.</p>
    <p>Curiosity piqued, you step into the boat, feeling the gentle sway beneath you. As you take a seat, a soft voice whispers from the waves, "Welcome, traveler! You have entered a world of wonders. This boat can take you to hidden islands filled with treasures and secrets. Will you embark on this journey?"</p>
    <p>You look around, the ocean stretching endlessly before you, and the horizon painted with hues of orange and pink as the sun begins to set. The choice is yours: will you sail into the unknown, or will you return to the safety of the shore?</p>
    <p>As you ponder your decision, a gentle breeze brushes against your face, carrying the scent of salt and adventure. The ocean seems to call to you, promising excitement and discovery. You take a deep breath, feeling the thrill of the unknown.</p>
    <p>With a determined heart, you grasp the oars and begin to row. The boat glides smoothly over the water, and soon you find yourself surrounded by a cluster of islands, each one more enchanting than the last. One island is covered in lush greenery, another is dotted with sparkling waterfalls, and yet another is home to a hidden cave that glows with a mysterious light.</p>
    <p>“Choose wisely, traveler,” the voice echoes again. “Each island holds its own adventure, filled with challenges and rewards. Will you explore the lush forest, seek the treasures of the waterfall, or uncover the secrets of the glowing cave?”</p>
    <p>The ocean awaits your decision, and the adventure is just beginning. What will you choose?</p>
</body>
</html>';
?>