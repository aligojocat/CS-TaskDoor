<?php
echo '<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Green Door Adventure</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
    <style>
        body {
            font-family: Arial, sans-serif;
            text-align: center;
            background-image: url("green.jpg"); /* Set the background image */
            background-size: cover; /* Cover the entire background */
            background-position: center; /* Center the background image */
            margin: 0;
            padding: 0; /* Remove padding */
            height: 100vh; /* Full height of the viewport */
            display: flex; /* Use flexbox for centering */
            flex-direction: column; /* Stack elements vertically */
            justify-content: center; /* Center vertically */
            align-items: center; /* Center horizontally */
            position: relative; /* Position relative for the overlay */
            overflow: hidden; /* Prevent overflow */
        }
        .overlay {
            position: absolute; /* Position overlay absolutely */
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background-color: rgba(0, 0, 0, 0.5); /* Black with 50% transparency */
            z-index: 1; /* Ensure overlay is above the background */
        }
        h1 {
            position: relative; /* Position text above the overlay */
            z-index: 2; /* Ensure text is above the overlay */
            color: #32cd32; /* Color for the title */
            font-size: 24px; /* Smaller font size for the title */
            text-shadow: 2px 2px 4px rgba(0, 0, 0, 0.7); /* Shadow for better readability */
            margin: 10px; /* Margin for spacing */
        }
        p {
            position: relative; /* Position text above the overlay */
            z-index: 2; /* Ensure text is above the overlay */
            color: #fff; /* Light text color for better contrast */
            font-size: 14px; /* Smaller font size for the story */
            line-height: 1.4; /* Line height for better readability */
            text-shadow: 1px 1px 3px rgba(0, 0, 0, 0.7); /* Shadow for better readability */
            width: 80%; /* Set a fixed width for better readability */
            margin: 10px auto; /* Center the paragraphs */
        }
        .back-button {
            position: absolute; /* Position the button absolutely */
            top: 20px; /* Distance from the top */
            left: 20px; /* Distance from the left */
            background-color: rgba(255, 255, 255, 0.8); /* Light background for the button */
            color: #000; /* Text color */
            border: none; /* No border */
            padding: 10px 15px; /* Padding for the button */
            border-radius: 5px; /* Rounded corners */
            cursor: pointer; /* Pointer cursor on hover */
            z-index: 2; /* Ensure button is above the overlay */
            font-size: 16px; /* Font size for the button */
        }
        .back-button:hover {
            background-color: rgba(255, 255, 255, 1); /* Change background on hover */
        }
    </style>
</head>
<body>

    <div class="overlay"></div> <!-- Overlay for transparency -->
    <button class="back-button" onclick="window.history.back();">Back</button> <!-- Back button -->
    <h1>Welcome to the Green Door Adventure!</h1>
    <p>As you step through the green door, you find yourself in a magical forest filled with vibrant colors and enchanting sounds. The air is fresh and fragrant, filled with the scent of blooming flowers and rich earth. Sunlight filters through the leaves, creating a beautiful mosaic of light and shadow on the forest floor.</p>
    <p>As you venture deeper into the woods, you notice the trees are ancient and wise, their trunks thick and gnarled. The gentle rustle of leaves and the distant sound of a bubbling brook create a symphony of nature that surrounds you.</p>
    <p>Suddenly, you come across a clearing where a magnificent, ancient tree stands tall, its branches stretching     high into the sky. At the base of the tree, you spot a small, intricately carved wooden box. You kneel down to examine it, your heart racing with anticipation.</p>
    <p>As you reach out to touch the box, a soft voice calls out to you from the depths of the forest. "Welcome, traveler! You have entered a realm of dreams and possibilities. The box you see before you holds a choice—one that can change your fate. Will you open it and discover what lies within?"</p>
    <p>You hesitate for a moment, contemplating the adventure that awaits. The forest around you seems to hold its breath, waiting for your decision. Will you embrace the unknown and unlock the secrets of this enchanted world, or will you turn back and leave the mysteries behind?</p>
    <p>As you ponder your choice, you feel a gentle breeze brush against your skin, as if the forest itself is encouraging you to take a leap of faith. The journey has just begun, and the possibilities are endless. What will you discover in this magical place?</p>
    <p>With a deep breath, you reach for the intricately carved box. As your fingers touch the smooth wood, a warm glow emanates from it, illuminating your surroundings. You can feel the energy pulsing through the air, as if the forest is alive and aware of your presence.</p>
    <p>As you slowly lift the lid, a soft, melodic chime fills the air, and a swirl of colorful lights escapes from the box, dancing around you like fireflies. Each light carries a whisper of a story, a memory, or a dream waiting to be realized. You realize that this box holds not just a choice, but a multitude of paths that could lead you to incredible adventures.</p>
    <p>Suddenly, the lights begin to coalesce into three distinct shapes, each representing a different journey. One shape resembles a majestic unicorn, its mane flowing like silk. Another takes the form of a wise old owl, its eyes filled with ancient knowledge. The last shape is that of a playful squirrel, its tail flicking with mischief and curiosity.</p>
    <p>“Choose wisely, traveler,” the soft voice echoes again. “Each path will lead you to a different adventure, filled with challenges and rewards. Will you ride the unicorn through enchanted meadows, seek wisdom with the owl, or embark on a playful quest with the squirrel?”</p>
    <p>The forest seems to hold its breath once more, waiting for your decision. The choice is yours, and the adventure is just beginning. What will you choose?</p>
</body>
</html>';
?>